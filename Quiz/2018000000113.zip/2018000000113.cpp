#include <bits/stdc++.h>
using namespace std;

struct items
{
    int weight,price, unit;
};

bool compare(items a,items b)
{
    return a.unit>b.unit;
}

int main()
{
    int n,W;
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    items arr[100];
   // items brr[n]
    cin>>n>>W;
    for(int i=0;i<=n;i++)
    {
        cin>>arr[i].weight>>arr[i].price;
        arr[i].unit=arr[i].price/arr[i].weight;
    }
    sort(&arr[0],&arr[n],compare);

    int count1=0;
    for(int i=0;i<=n;i++)
    {
        if(W > arr[i].weight)
        {
            count1=count1+arr[i].price;
            W   =W - arr[i].weight;
        }
        else
        {
            count1 = count1 + W*arr[i].unit;
            W = 0;
        }
    }
    cout << "Total Profit = " << count1 << endl ;
    return 0;
}
